"""
Support for working with delimited data files.
"""